package com.bharath.patterns.dao;

public interface EmployeeDAO {
	
	void create(Employee employee);

}
