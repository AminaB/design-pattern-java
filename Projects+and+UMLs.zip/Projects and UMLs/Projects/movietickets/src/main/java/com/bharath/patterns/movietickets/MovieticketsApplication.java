package com.bharath.patterns.movietickets;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieticketsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieticketsApplication.class, args);
	}
}
