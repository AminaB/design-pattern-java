package com.bharath.patterns.movietickets.dao;

import com.bharath.patterns.movietickets.entities.Ticket;

public interface TicketDao {
	
	void create(Ticket ticket);

}
