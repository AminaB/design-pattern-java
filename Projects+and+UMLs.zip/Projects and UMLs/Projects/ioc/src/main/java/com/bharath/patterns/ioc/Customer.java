package com.bharath.patterns.ioc;

public interface Customer {

	void pay();
}
