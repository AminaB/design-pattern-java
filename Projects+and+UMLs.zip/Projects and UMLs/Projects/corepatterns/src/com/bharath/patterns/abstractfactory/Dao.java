package com.bharath.patterns.abstractfactory;

public interface Dao {

	void save();
}
