package com.bharath.patterns.adapter;

public interface WeatherFinder {

	int find(String city);

}
