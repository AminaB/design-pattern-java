package com.bharath.patterns.flyweight;

public class Test {

	public static void main(String[] args) {

		PaintApp app = new PaintApp();
		app.render(10);

	}

}
